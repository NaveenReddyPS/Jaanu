# Cointab Assignment

# We are building mostly 3 pages :-

### 1. HomePage (Landing page)

### 2. Signup Page

### 3. Login Page  
 
      If you enter Wrong Password Five times , then Your account will block for 24 hrs

# Deployment : 

### BackEnd  : https://puce-elated-hatchling.cyclic.app
### FrontEnd : https://graceful-mermaid-ac1b10.netlify.app/

# Glimpse of My work



## LOGIN PAGE:

![LOGIN](https://github.com/lokeshahire/cointabAssignment/blob/main/img/login.png?raw=true)
<br>
<br>
<br>

## SIGNUP PAGE :

![PROFILE](https://github.com/lokeshahire/cointabAssignment/blob/main/img/sign.png?raw=true)
<br>
<br>
<br>

## HOMEPAGE :

![HOMEPAGE](https://github.com/lokeshahire/cointabAssignment/blob/main/img/home.png?raw=true)
<br>
<br>
<br>
<br>

Thank You :)
